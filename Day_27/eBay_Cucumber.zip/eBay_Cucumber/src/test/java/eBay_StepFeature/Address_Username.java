package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Address_Username 
{
	WebDriver driver;
    PageClass pg;
    
    
    @Given("Home page of Ebay should be available")
    public void home_page_of_ebay_should_be_available() 
    {
    	driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.ebay.com");
        pg = new PageClass(driver);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    	
    }
    
    @When("first login in account")
    public void first_login_in_account() throws InterruptedException 
    {
    	driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a")).click();

        pg.username();
        pg.continues();
        Thread.sleep(2000);
        pg.password();
        pg.submit();
    }
    
    
    @When("navigate to the account settings page and update address and update my username")
    public void navigate_to_the_account_settings_page_and_update_address_and_update_my_username() throws InterruptedException {
		pg.add_username();
	}

	@Then("profile should be updated successfully")
	public void profile_should_be_updated_successfully() {
		System.out.println("Profile update successful");
		driver.close();
	}
}
