package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Description 
{
	WebDriver driver;
	PageClass pg;
	@Given("open the eBay home page to check desc")
	public void open_the_e_bay_home_page_to_check_desc(){
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}
	@When("search for product and click on the that product image")
	public void search_for_product_and_click_on_the_that_product_image()
	{
		pg.descr();
	}
	@Then("the open product description page")
	public void the_open_product_description_page()
	{
		driver.close();
	}
}
