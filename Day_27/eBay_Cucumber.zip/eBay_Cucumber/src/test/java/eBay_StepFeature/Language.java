package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Language 
{
	WebDriver driver;
	PageClass pg;
	@Given("open the eBay home page to change language")
	public void open_the_e_bay_home_page_to_change_language() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}
	@When("scroll down the page and change language")
	public void scroll_down_the_page_and_change_language()
	{
		pg.lan();
	}
	@Then("the site should be displayed in selected language")
	public void the_site_should_be_displayed_in_selected_language()
	{
		driver.close();
	}
}
