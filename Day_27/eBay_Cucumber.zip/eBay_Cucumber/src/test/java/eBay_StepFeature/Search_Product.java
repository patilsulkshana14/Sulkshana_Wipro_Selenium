package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Search_Product {
	WebDriver driver;
	PageClass pg ;
	
	@Given("home page should be open in default browser")
	public void home_page_should_be_open_in_default_browser() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}

	@When("enter product to search and click on search button")
	public void enter_product_to_search_and_click_on_search_button() throws InterruptedException {
	    pg.search();
	}

	@Then("related result should be displayed")
	public void related_result_should_be_displayed() {
	    driver.close();
	}
	
}
