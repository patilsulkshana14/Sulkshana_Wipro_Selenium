package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Shop_by_category 
{
	WebDriver driver;
	PageClass pg;
	@Given("show home page")
	public void show_home_page() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}
	@When("select product category from the Shop by category dropdown")
	public void select_product_category_from_the_shop_by_category_dropdown() {
		 
		 pg.shopcate();
	}

	@Then("the search results for that Category")
	public void the_search_results_for_that_category() {
	    driver.close();
	}

}
