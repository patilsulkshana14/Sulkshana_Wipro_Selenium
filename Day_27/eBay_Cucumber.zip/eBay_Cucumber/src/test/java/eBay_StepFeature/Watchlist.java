package eBay_StepFeature;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Watchlist 
{
	WebDriver driver;
    PageClass pg;
    @Before
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.ebay.com");
        pg = new PageClass(driver);
    }
    @Given("logged into Ebay website")
    public void logged_into_ebay_website() throws InterruptedException
    {
    	driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a")).click();

        pg.username();
        pg.continues();
        Thread.sleep(2000);
        pg.password();
        pg.submit();
    }
    
    @When("search product and I add the product from results to my Watchlist")
    public void search_product_and_i_add_the_product_from_results_to_my_watchlist()
    {
    	pg.Watchlist();
    }
    @Then("The product should be added successfully in Watchlist")
    public void the_product_should_be_added_successfully_in_watchlist()
    {
    	driver.close();
    }
}
