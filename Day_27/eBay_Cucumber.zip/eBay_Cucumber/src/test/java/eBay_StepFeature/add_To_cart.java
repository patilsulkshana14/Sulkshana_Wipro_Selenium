package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class add_To_cart 
{
	WebDriver driver;
	PageClass pg;
	@Given("open the eBay home page")
	public void open_the_e_bay_home_page() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}

	@When("enter to search for add to cart and click on that product and I click on Add to cart button")
	public void enter_to_search_for_add_to_cart_and_click_on_that_product_and_i_click_on_add_to_cart_button() throws InterruptedException 
	{
	    pg.cart();
	}
	@Then("the product should be added to the cart successfully")
	public void the_product_should_be_added_to_the_cart_successfully() {
	    driver.close();
	}

}
