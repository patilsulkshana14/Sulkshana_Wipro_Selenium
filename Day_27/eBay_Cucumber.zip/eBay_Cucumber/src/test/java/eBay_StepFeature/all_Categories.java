package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class all_Categories 
{
	WebDriver driver;
	PageClass pg;
	
	@Given("show home page in deafult browser")
	public void show_home_page_in_deafult_browser() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}
	
	@When("select category you want from the Shop by category")
	public void select_category_you_want_from_the_shop_by_category()
	{
		pg.allcateg();
	}
	
	@Then("the search results for relavent result for that category should be displayed")
	public void the_search_results_for_relavent_result_for_that_category_should_be_displayed()
	{
		driver.close();
	}
}
