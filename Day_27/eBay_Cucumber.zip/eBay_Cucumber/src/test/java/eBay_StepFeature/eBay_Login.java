package eBay_StepFeature;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class eBay_Login
{
	WebDriver driver;
	PageClass pg;
	@Given("login page should be open in default browser")
	public void login_page_should_be_open_in_default_browser() {
		driver=new ChromeDriver();
	    driver.get("https://www.ebay.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    pg = new PageClass(driver);
	}

	@When("click on login button and enter username")
	public void click_on_login_button_and_enter_username() 
	{
		driver.findElement(By.xpath("//*[@id=\"gh\"]/nav/div[1]/span[1]/span/a")).click();
	    pg.username();
	}
	@When("Click on continue button")
	public void click_on_continue_button() {
	    pg.continues();
	}

	@When("add password")
	public void add_password() 
	{
	    pg.password();
	}

	@When("click on signin button")
	public void click_on_signin_button() {
	    pg.submit();
	}
	@Then("Login successful and open home page")
	public void login_successful_and_open_home_page() {
	    driver.close();
	}
	
}
